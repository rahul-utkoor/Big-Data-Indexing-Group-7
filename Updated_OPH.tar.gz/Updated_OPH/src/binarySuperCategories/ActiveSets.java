package binarySuperCategories;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import features.Feature;

public class ActiveSets {
	public Map<Integer , List<List<Feature> > > activeset;
	public static List<Feature> A;
	public static List<Feature> B;
	
	public ActiveSets(int index , int S , List<Integer> I , Map<Integer , SuperCategories > C , Map<Integer , HammingSuperCategories > hC) {
		activeset = new HashMap<Integer , List<List<Feature> > >();
		for(int i = 1 ; i < S-1 ; i++) {
			List<List<Feature> > temp = new ArrayList<List<Feature> >();
			A = new ArrayList<Feature>(calculateAS(C.get(index).getEntry(i) , hC.get(index).getEntry(i-1)));
			B = new ArrayList<Feature>(calculateAS(hC.get(index).getEntry(i+1) , C.get(index).getEntry(i)));
			temp.add(new ArrayList<Feature>(A));
			temp.add(new ArrayList<Feature>(B));
			activeset.put(i, temp);
		}
	}
	
	public static List<Feature> calculateAS(List<List<Feature> > X , List<List<Feature> >  Y) {
		List<Feature> temp = new ArrayList<Feature>();
		for(int i = 0 ; i < X.get(0).size() ; i++) {
			if(!Y.get(0).contains(X.get(0).get(i))) {
				temp.add(X.get(0).get(i));
			}
		}
		return temp;
	}
}
